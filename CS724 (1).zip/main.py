# main.py

import database
import sys
import cv2
import numpy as np
from PyQt5.QtWidgets import (QApplication, QWidget, QPushButton, QLabel,
                             QHBoxLayout, QVBoxLayout)
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer
from pose_detector import poseDetector
import serial
database.create_database()
def update_feedback_and_count(elbow, shoulder, hip, direction, form):
    """Determines the feedback message and updates the count based on the angles."""
    feedback = "Fix Form"
    if elbow > 160 and shoulder > 40 and hip > 160:
        form = 1
    if form == 1:
        if elbow <= 90 and hip > 160:
            feedback = "Up"
            if direction == 0:
                # count += 0.5
                direction = 1
        elif elbow > 160 and shoulder > 40 and hip > 160:
            feedback = "Down"
            if direction == 1:
                # count += 0.5
                direction = 0
        else:
            feedback = "Fix Form"
    return feedback, direction, form

def draw_ui(img, per, bar, count, feedback, form):
    """Draws the UI elements on the image."""
    if form == 1:
        cv2.rectangle(img, (750, 50), (770, 380), (0, 255, 0), 3)
        cv2.rectangle(img, (750, int(bar)), (770, 380), (0, 255, 0), cv2.FILLED)
        cv2.putText(img, f'{int(per)}%', (750, 430), cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 2)

    cv2.rectangle(img, (0, 380), (100, 480), (0, 255, 0), cv2.FILLED)
    cv2.putText(img, str(int(count)), (25, 455), cv2.FONT_HERSHEY_PLAIN, 5, (255, 0, 0), 5)
    
    cv2.rectangle(img, (500, 0), (800, 40), (255, 255, 255), cv2.FILLED)
    cv2.putText(img, feedback, (500, 35), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0), 2)

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Pushup Counter')
        self.setGeometry(100, 100, 300, 200)
        self.initUI()
        
    def initUI(self):
        self.start_button = QPushButton('Start Camera', self)
        self.start_button.clicked.connect(self.open_camera_window)
        
        layout = QVBoxLayout()
        layout.addWidget(self.start_button)
        self.setLayout(layout)
        
    def open_camera_window(self):
        self.camera_window = CameraWindow()
        self.camera_window.show()
        self.close()

class CameraWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Live Camera Feed')
        self.setGeometry(100, 100, 800, 600)
        self.initUI()
        self.cap = cv2.VideoCapture(0)
        
        self.detector = poseDetector()
        self.count = 0
        self.direction = 0
        self.form = 0
        self.feedback = "Fix Form"
        self.is_counting = False
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(10)  # Update every 30 ms
        try:
            self.serial_port = serial.Serial('/dev/cu.usbserial-10', 9600)  # Replace 'COM3' with your Arduino port
        except serial.SerialException as e:
            print(f"Could not open serial port: {e}")
            self.serial_port = None

    def initUI(self):
        self.image_label = QLabel(self)
        self.capture_button = QPushButton('Start', self)
        self.reset_button = QPushButton('Reset', self)
        
        self.capture_button.clicked.connect(self.start_counting)
        self.reset_button.clicked.connect(self.reset_count)
        
        h_layout = QHBoxLayout()
        h_layout.addWidget(self.capture_button)
        h_layout.addWidget(self.reset_button)
        
        v_layout = QVBoxLayout()
        v_layout.addWidget(self.image_label)
        v_layout.addLayout(h_layout)
        
        self.setLayout(v_layout)
        
    def update_frame(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.resize(frame, (800, 600))
            frame = cv2.flip(frame, 1)
            # Read from the serial port
            # if self.serial_port and self.serial_port.in_waiting:
            #     try:
            #         line = self.serial_port.readline().decode('utf-8').strip()
            #         if line.startswith('COUNT:'):
            #             count_str = line.split(':')[1].strip()
            #             self.count = float(count_str)
            #             print(self.count)
            #     except Exception as e:
            #         print(f"Error reading from serial port: {e}")
            if self.serial_port and self.serial_port.in_waiting:
                try:
                    # Read a line from the serial port
                    line = self.serial_port.readline().decode('utf-8').strip()
        
                    # Check if the line contains both distance and count
                    if "Distance (cm):" in line and "Push-Up Count:" in line:
                        # Extract the distance
                        distance_str = line.split("Distance (cm):")[1].split("|")[0].strip()
                        distance = float(distance_str)
            
                        # Extract the count
                        count_str = line.split("Push-Up Count:")[1].strip()
                        count = float(count_str)
            
                        # Store or print the values
                        self.distance = distance
                        self.count = count
                        
                        print(f"Distance: {self.distance} cm, Count: {self.count}")
                except Exception as e:
                    print(f"Error reading from serial port: {e}")

            if self.is_counting:
                frame = self.process_frame(frame)
            else:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Convert to QImage
            height, width, channel = frame.shape
            step = channel * width
            qImg = QImage(frame.data, width, height, step, QImage.Format_RGB888)
            # Display the image
            self.image_label.setPixmap(QPixmap.fromImage(qImg))
    
    def process_frame(self, img):
        img = self.detector.findPose(img, False)
        lmList = self.detector.findPosition(img, False)

        if len(lmList) != 0:
            elbow = self.detector.findAngle(img, 11, 13, 15)
            shoulder = self.detector.findAngle(img, 13, 11, 23)
            hip = self.detector.findAngle(img, 11, 23, 25)
            per = np.interp(elbow, (90, 160), (0, 100))
            bar = np.interp(elbow, (90, 160), (380, 50))
            self.feedback, self.direction, self.form = update_feedback_and_count(
                elbow, shoulder, hip, self.direction, self.form)
            draw_ui(img, per, bar, self.count, self.feedback, self.form)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        return img
    
    def start_counting(self):
        self.is_counting = True
        self.capture_button.setEnabled(False)

    def reset_count(self):
        """Save the pushup count to the database."""
        exercise_name = 'Pushup'
        cnt = self.count
        database.save_exercise_data(exercise_name, cnt)
        self.count = 0
        self.direction = 0
        self.form = 0
        self.feedback = "Fix Form"
        self.is_counting = False
        self.capture_button.setEnabled(True)
    
    def closeEvent(self, event):
        self.cap.release()
        if self.serial_port:
            self.serial_port.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec_())
