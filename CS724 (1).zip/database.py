# database.py
import sqlite3
from datetime import datetime

def create_database():
    """Create the database and table if it doesn't exist."""
    conn = sqlite3.connect('exercise_data.db')
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS exercises (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exercise_name TEXT NOT NULL,
        count INTEGER NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    conn.commit()
    conn.close()

def save_exercise_data(exercise_name, count):
    """Save exercise data with the timestamp to the database."""
    conn = sqlite3.connect('exercise_data.db')
    cursor = conn.cursor()

    # Get the current date and time (24-hour format)
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    cursor.execute('''
    INSERT INTO exercises (exercise_name, count, timestamp)
    VALUES (?, ?, ?)
    ''', (exercise_name, count, timestamp))

    conn.commit()
    conn.close()

def get_previous_exercise_data():
    """Retrieve all previous exercise data from the database."""
    conn = sqlite3.connect('exercise_data.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM exercises ORDER BY timestamp DESC')
    data = cursor.fetchall()

    conn.close()
    return data
import sqlite3

def connect_db():
    """Connect to the SQLite database and return the connection."""
    conn = sqlite3.connect('pushups.db')  # Or use your preferred database
    return conn

def create_table():
    """Create the table to store the pushup count if it doesn't exist."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS pushup_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        count REAL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

def insert_count(count):
    """Insert the pushup count into the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO pushup_history (count) VALUES (?)''', (count,))
    
    conn.commit()
    conn.close()
entries = [
    ('Pushup', 0.0, '2024-11-20 13:54:00'),
    ('Pushup', 3.5, '2024-11-20 13:53:59'),
    ('Pushup', 3.0, '2024-11-20 13:53:58'),
    ('Pushup', 0.5, '2024-11-20 13:53:57'),
    ('Pushup', 3.5, '2024-11-20 13:53:56'),
    ('Pushup', 0.5, '2024-11-20 13:53:55'),
    ('Pushup', 0.5, '2024-11-20 13:53:54'),
    ('Pushup', 0.0, '2024-11-20 13:53:53'),
    ('Pushup', 3.0, '2024-11-20 13:53:52'),
    ('Pushup', 0.5, '2024-11-20 13:53:51'),
    ('Pushup', 0.0, '2024-11-20 13:53:50'),
    ('Pushup', 3.5, '2024-11-20 13:53:49'),
    ('Pushup', 0.0, '2024-11-20 13:53:48'),
    ('Pushup', 3.0, '2024-11-20 13:53:47'),
    ('Pushup', 0.5, '2024-11-20 13:53:46'),
    ('Pushup', 3.0, '2024-11-20 13:53:45'),
    ('Pushup', 0.0, '2024-11-20 13:53:44'),
    ('Pushup', 0.5, '2024-11-20 13:53:43'),
    ('Pushup', 3.0, '2024-11-20 13:53:42'),
    ('Pushup', 0.0, '2024-11-20 13:53:41'),
    ('Pushup', 3.5, '2024-11-20 13:53:40'),
    ('Pushup', 0.5, '2024-11-20 13:53:39'),
    ('Pushup', 0.0, '2024-11-20 13:53:38'),
    ('Pushup', 3.0, '2024-11-20 13:53:37'),
    ('Pushup', 0.5, '2024-11-20 13:53:36'),
    ('Pushup', 3.5, '2024-11-20 13:53:35'),
    ('Pushup', 3.0, '2024-11-20 13:53:34'),
    ('Pushup', 0.5, '2024-11-20 13:53:33'),
    ('Pushup', 0.5, '2024-11-20 13:53:32'),
    ('Pushup', 3.0, '2024-11-20 13:53:31'),
    ('Pushup', 0.5, '2024-11-20 13:53:30'),
    ('Pushup', 0.0, '2024-11-20 13:53:29'),
    ('Pushup', 3.5, '2024-11-20 13:53:28'),
    ('Pushup', 3.0, '2024-11-20 13:53:27'),
    ('Pushup', 3.0, '2024-11-20 13:53:26'),
    ('Pushup', 0.5, '2024-11-20 13:53:25'),
    ('Pushup', 0.5, '2024-11-20 13:53:24'),
    ('Pushup', 0.5, '2024-11-20 13:53:23'),
    ('Pushup', 3.0, '2024-11-20 13:53:22'),
    ('Pushup', 0.5, '2024-11-20 13:53:21'),
    ('Pushup', 0.0, '2024-11-20 13:53:20'),
]