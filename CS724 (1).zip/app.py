from flask import Flask, render_template, redirect, url_for, jsonify
import subprocess
import database
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start-pushups', methods=['POST'])
def start_pushups():
    try:
        # Execute main.py for Pushups
        result = subprocess.run(['python', 'main.py'], capture_output=True, text=True)
        return f"<h1>Pushups Completed:</h1><p>{result.stdout}</p><br><a href='/'>Go Back</a>"
    except Exception as e:
        return f"<h1>Error:</h1><p>{str(e)}</p><br><a href='/'>Go Back</a>"

@app.route('/start-situps', methods=['POST'])
def start_situps():
    try:
        # Execute main.py for Situps
        result = subprocess.run(['python', 'main.py'], capture_output=True, text=True)
        return f"<h1>Situps Completed:</h1><p>{result.stdout}</p><br><a href='/'>Go Back</a>"
    except Exception as e:
        return f"<h1>Error:</h1><p>{str(e)}</p><br><a href='/'>Go Back</a>"

@app.route('/get-pushup-history', methods=['GET'])
def get_pushup_history():
    """Fetch the pushup history from the database."""
    history = database.get_previous_exercise_data()
    formatted_history = [{"exercise_name": record[1], "count": record[2], "timestamp": record[3]} for record in history]
    return jsonify(formatted_history)

if __name__ == '__main__':
    app.run(debug=True)
